package com.example.mydownloader;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText urlInput;
    private Button downloadButton;
    private DownloadManager downloadManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        downloadButton = findViewById(R.id.downloadButton);

        downloadManager =
                (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

        downloadButton.setOnClickListener(v -> startDownload());
    }

    private void startDownload() {

        String url = urlInput.getText().toString().trim();

        // Check empty URL
        if (url.isEmpty()) {
            show("ERROR: Enter a URL");
            return;
        }

        // Check HTTP/HTTPS
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            show("ERROR: URL must start with http:// or https://");
            return;
        }

        show("Starting download...");

        try {

            Uri uri = Uri.parse(url);

            DownloadManager.Request request =
                    new DownloadManager.Request(uri);

            request.setTitle("MyDownloader");
            request.setDescription("Downloading file...");

            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );

            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);

            // Save to the normal Downloads folder
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "MyDownloader_" + System.currentTimeMillis()
            );

            long downloadId = downloadManager.enqueue(request);

            show("Download started!");

            // Monitor this download
            monitorDownload(downloadId);

        } catch (Exception e) {

            show("DOWNLOAD ERROR:\n" + e.getClass().getSimpleName()
                    + "\n" + e.getMessage());
        }
    }

    private void monitorDownload(long downloadId) {

        new Thread(() -> {

            boolean finished = false;

            while (!finished) {

                DownloadManager.Query query =
                        new DownloadManager.Query();

                query.setFilterById(downloadId);

                Cursor cursor = null;

                try {

                    cursor = downloadManager.query(query);

                    if (cursor != null && cursor.moveToFirst()) {

                        int status = cursor.getInt(
                                cursor.getColumnIndexOrThrow(
                                        DownloadManager.COLUMN_STATUS
                                )
                        );

                        if (status == DownloadManager.STATUS_SUCCESSFUL) {

                            finished = true;

                            runOnUiThread(() ->
                                    show("DOWNLOAD COMPLETE!"));

                        } else if (status == DownloadManager.STATUS_FAILED) {

                            finished = true;

                            int reason = cursor.getInt(
                                    cursor.getColumnIndexOrThrow(
                                            DownloadManager.COLUMN_REASON
                                    )
                            );

                            runOnUiThread(() ->
                                    show("DOWNLOAD FAILED!\nReason: " + reason));
                        }
                    }

                } catch (Exception e) {

                    finished = true;

                    String error = e.getClass().getSimpleName()
                            + ": " + e.getMessage();

                    runOnUiThread(() ->
                            show("DOWNLOAD ERROR!\n" + error));

                } finally {

                    if (cursor != null) {
                        cursor.close();
                    }
                }

                if (!finished) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        finished = true;
                    }
                }
            }

        }).start();
    }

    private void show(String message) {

        runOnUiThread(() ->
                Toast.makeText(
                        MainActivity.this,
                        message,
                        Toast.LENGTH_LONG
                ).show()
        );
    }
}