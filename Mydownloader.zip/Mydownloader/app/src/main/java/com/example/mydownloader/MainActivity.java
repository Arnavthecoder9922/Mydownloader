package com.example.mydownloader;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.yausername.youtubedl_android.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLException;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.File;

public class MainActivity extends Activity {

    private EditText urlInput;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        downloadButton = findViewById(R.id.downloadButton);

        // Initialize yt-dlp and FFmpeg
        try {
            YoutubeDL.getInstance().init(this);
            FFmpeg.getInstance().init(this);
        } catch (YoutubeDLException e) {
            showError("Initialization failed:\n" + e.getMessage());
            return;
        }

        downloadButton.setOnClickListener(v -> startDownload());
    }

    private void startDownload() {

        String url = urlInput.getText().toString().trim();

        if (url.isEmpty()) {
            showError("Enter a YouTube URL");
            return;
        }

        if (!url.startsWith("http://") &&
                !url.startsWith("https://")) {
            showError("Invalid URL");
            return;
        }

        downloadButton.setEnabled(false);

        Toast.makeText(
                this,
                "Download started!",
                Toast.LENGTH_SHORT
        ).show();

        new Thread(() -> {

            try {

                File downloadFolder =
                        Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_DOWNLOADS
                        );

                File appFolder =
                        new File(downloadFolder, "MyDownloader");

                if (!appFolder.exists()) {
                    appFolder.mkdirs();
                }

                YoutubeDLRequest request =
                        new YoutubeDLRequest(url);

                /*
                 * Prefer MP4 video + M4A audio.
                 * If that isn't available, fall back to the
                 * best single MP4 stream.
                 */
                request.addOption(
                        "-f",
                        "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
                );

                // Merge separate video/audio streams into MP4.
                request.addOption(
                        "--merge-output-format",
                        "mp4"
                );

                // Save using the video's title.
                request.addOption(
                        "-o",
                        new File(
                                appFolder,
                                "%(title)s.%(ext)s"
                        ).getAbsolutePath()
                );

                YoutubeDL.getInstance().execute(
                        request,
                        (progress, etaInSeconds) -> {

                            runOnUiThread(() -> {

                                downloadButton.setText(
                                        "Downloading " +
                                        Math.round(progress) +
                                        "%"
                                );
                            });
                        }
                );

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);
                    downloadButton.setText("Download");

                    Toast.makeText(
                            MainActivity.this,
                            "DOWNLOAD COMPLETE!",
                            Toast.LENGTH_LONG
                    ).show();
                });

            } catch (Exception e) {

                String error = e.getMessage();

                if (error == null || error.isEmpty()) {
                    error = e.getClass().getSimpleName();
                }

                final String finalError = error;

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);
                    downloadButton.setText("Download");

                    showError(
                            "DOWNLOAD FAILED:\n" +
                            finalError
                    );
                });
            }

        }).start();
    }

    private void showError(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }

    @Override
    protected void onDestroy() {

        try {
            YoutubeDL.getInstance().destroyProcessById(
                    "MyDownloader"
            );
        } catch (Exception ignored) {
        }

        super.onDestroy();
    }
}