package com.example.mydownloader;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLException;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.File;

public class MainActivity extends Activity {

    private EditText urlInput;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        downloadButton = findViewById(R.id.downloadButton);

        try {
            YoutubeDL.getInstance().init(this);
        } catch (YoutubeDLException e) {
            showMessage("yt-dlp initialization failed:\n" + e.getMessage());
            return;
        }

        downloadButton.setOnClickListener(v -> startDownload());
    }

    private void startDownload() {

        String url = urlInput.getText().toString().trim();

        if (url.isEmpty()) {
            showMessage("ERROR: Enter a YouTube URL");
            return;
        }

        if (!url.startsWith("http://") &&
                !url.startsWith("https://")) {
            showMessage("ERROR: Invalid URL");
            return;
        }

        downloadButton.setEnabled(false);
        showMessage("Download started!");

        new Thread(() -> {

            try {

                File downloads =
                        Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_DOWNLOADS
                        );

                File folder =
                        new File(downloads, "MyDownloader");

                if (!folder.exists()) {
                    folder.mkdirs();
                }

                YoutubeDLRequest request =
                        new YoutubeDLRequest(url);

                request.addOption(
                        "-f",
                        "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
                );

                request.addOption(
                        "--merge-output-format",
                        "mp4"
                );

                request.addOption(
                        "-o",
                        new File(
                                folder,
                                "%(title)s.%(ext)s"
                        ).getAbsolutePath()
                );

                // Execute the download.
                YoutubeDL.getInstance().execute(request);

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);

                    showMessage("DOWNLOAD COMPLETE!\nCheck Downloads/MyDownloader");

                });

            } catch (Exception e) {

                String error = e.getMessage();

                if (error == null || error.isEmpty()) {
                    error = e.getClass().getSimpleName();
                }

                final String finalError = error;

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);

                    showMessage(
                            "DOWNLOAD FAILED!\n" + finalError
                    );

                });
            }

        }).start();
    }

    private void showMessage(String message) {

        runOnUiThread(() ->
                Toast.makeText(
                        MainActivity.this,
                        message,
                        Toast.LENGTH_LONG
                ).show()
        );
    }
}