package com.example.mydownloader;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.youtubedl_android.YoutubeDLException;

import java.io.File;

public class MainActivity extends Activity {

    private EditText urlInput;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        downloadButton = findViewById(R.id.downloadButton);

        try {
            YoutubeDL.getInstance().init(this);
        } catch (YoutubeDLException e) {
            show("yt-dlp initialization failed:\n" + e.getMessage());
            return;
        }

        downloadButton.setOnClickListener(v -> startDownload());
    }

    private void startDownload() {

        String url = urlInput.getText().toString().trim();

        if (url.isEmpty()) {
            show("ERROR: Enter a YouTube URL");
            return;
        }

        if (!url.startsWith("http://") &&
                !url.startsWith("https://")) {
            show("ERROR: Invalid URL");
            return;
        }

        downloadButton.setEnabled(false);
        downloadButton.setText("Downloading...");

        show("Download started!");

        new Thread(() -> {

            try {

                File downloads = Environment
                        .getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_DOWNLOADS
                        );

                File folder = new File(
                        downloads,
                        "MyDownloader"
                );

                if (!folder.exists()) {
                    folder.mkdirs();
                }

                YoutubeDLRequest request =
                        new YoutubeDLRequest(url);

                request.addOption(
                        "-f",
                        "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
                );

                request.addOption(
                        "--merge-output-format",
                        "mp4"
                );

                request.addOption(
                        "-o",
                        new File(
                                folder,
                                "%(title)s.%(ext)s"
                        ).getAbsolutePath()
                );

                YoutubeDL.getInstance().execute(
                        request,
                        (progress, etaInSeconds) -> {

                            runOnUiThread(() ->
                                    downloadButton.setText(
                                            "Downloading " +
                                            Math.round(progress) +
                                            "%"
                                    )
                            );
                        }
                );

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);
                    downloadButton.setText("Download");

                    show("DOWNLOAD COMPLETE!");
                });

            } catch (Exception e) {

                String error = e.getMessage();

                if (error == null || error.isEmpty()) {
                    error = e.getClass().getSimpleName();
                }

                final String finalError = error;

                runOnUiThread(() -> {

                    downloadButton.setEnabled(true);
                    downloadButton.setText("Download");

                    show("DOWNLOAD FAILED:\n" + finalError);
                });
            }

        }).start();
    }

    private void show(String message) {

        runOnUiThread(() ->
                Toast.makeText(
                        MainActivity.this,
                        message,
                        Toast.LENGTH_LONG
                ).show()
        );
    }
}