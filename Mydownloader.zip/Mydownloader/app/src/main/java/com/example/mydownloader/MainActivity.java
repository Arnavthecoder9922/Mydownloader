package com.example.mydownloader;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText urlInput;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        downloadButton = findViewById(R.id.downloadButton);

        downloadButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Download Started!",
                    Toast.LENGTH_SHORT
            ).show();

            startDownload();
        });
    }

    private void startDownload() {
        String url = urlInput.getText().toString().trim();

        if (url.isEmpty()) {
            Toast.makeText(
                    this,
                    "Enter a download URL",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            Toast.makeText(
                    this,
                    "Enter a valid HTTP/HTTPS URL",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {
            DownloadManager.Request request =
                    new DownloadManager.Request(Uri.parse(url));

            request.setTitle("MyDownloader");
            request.setDescription("Downloading...");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );

            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "MyDownloader_File"
            );

            DownloadManager manager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

            manager.enqueue(request);

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Download failed to start",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
  }